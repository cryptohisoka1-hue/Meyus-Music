import sqlite3
import json
from config import DB_NAME

def init_db():
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    # Oyun masaları tablosu
    c.execute('''CREATE TABLE IF NOT EXISTS games
                 (chat_id INTEGER PRIMARY KEY, 
                  status TEXT, 
                  players TEXT, 
                  deck TEXT, 
                  discard_pile TEXT, 
                  current_player_idx INTEGER, 
                  direction INTEGER,
                  current_color TEXT)''')
    conn.commit()
    conn.close()

def get_game(chat_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("SELECT * FROM games WHERE chat_id=?", (chat_id,))
    row = c.fetchone()
    conn.close()
    if row:
        return {
            "chat_id": row[0],
            "status": row[1],
            "players": json.loads(row[2]),
            "deck": json.loads(row[3]),
            "discard_pile": json.loads(row[4]),
            "current_player_idx": row[5],
            "direction": row[6],
            "current_color": row[7]
        }
    return None

def save_game(game_data):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute('''INSERT OR REPLACE INTO games 
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
              (game_data["chat_id"], 
               game_data["status"], 
               json.dumps(game_data["players"]), 
               json.dumps(game_data["deck"]), 
               json.dumps(game_data["discard_pile"]), 
               game_data["current_player_idx"], 
               game_data["direction"],
               game_data.get("current_color")))
    conn.commit()
    conn.close()

def delete_game(chat_id):
    conn = sqlite3.connect(DB_NAME)
    c = conn.cursor()
    c.execute("DELETE FROM games WHERE chat_id=?", (chat_id,))
    conn.commit()
    conn.close()
