import logging
from telegram.ext import Application, CommandHandler, CallbackQueryHandler, InlineQueryHandler
from config import TOKEN
from database import init_db, get_game, save_game
from game import create_deck
from inline import handle_inline_query
from callbacks import handle_callback
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

logging.basicConfig(level=logging.INFO)

async def start_game(update, context):
    chat_id = update.message.chat_id
    init_db()
    
    deck = create_deck()
    top_card = deck.pop()
    
    game_data = {
        "chat_id": chat_id,
        "status": "waiting",
        "players": [],
        "deck": deck,
        "discard_pile": [top_card],
        "current_player_idx": 0,
        "direction": 1,
        "current_color": top_card["color"]
    }
    save_game(game_data)
    
    keyboard = [[InlineKeyboardButton("Oyuna Katıl", callback_data="join_game")]]
    reply_markup = InlineKeyboardMarkup(keyboard)
    
    await update.message.reply_text(
        "🃏 **Meyus UNO Başlıyor!**\n\nKatılmak için aşağıdaki butona tıklayın.",
        reply_markup=reply_markup,
        parse_mode="Markdown"
    )

def main():
    application = Application.builder().token(TOKEN).build()
    
    application.add_handler(CommandHandler("uno", start_game))
    application.add_handler(CallbackQueryHandler(handle_callback))
    application.add_handler(InlineQueryHandler(handle_inline_query))
    
    print("Meyus UNO Bot Çalışıyor...")
    application.run_polling()

if __name__ == "__main__":
    main()
