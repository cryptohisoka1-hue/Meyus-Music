import uuid
from telegram import InlineQueryResultPhoto, InlineQueryResultArticle, InputTextMessageContent
from database import get_game
from game import can_play
from config import CARD_BASE_URL

async def handle_inline_query(update, context):
    query = update.inline_query.query
    user_id = update.inline_query.from_user.id
    
    # Kullanıcının aktif bir oyunu var mı? (Basitleştirilmiş: Son chat_id'yi bulmak gerekebilir)
    # Burada mantık olarak kullanıcının dahil olduğu aktif oyunu bulmalısınız.
    # Şimdilik örnek bir yapı kuruyoruz:
    
    results = []
    
    # Not: Gerçek uygulamada kullanıcının hangi chat_id'de olduğunu 
    # bir 'user_sessions' tablosunda tutmalısınız.
    
    # Eğer oyun bulunamazsa bilgilendirme göster
    results.append(
        InlineQueryResultArticle(
            id="info",
            title="Meyus UNO",
            description="Kartlarınızı görmek için bir oyuna katılın.",
            input_message_content=InputTextMessageContent("Meyus UNO botu ile eğlenceye katıl!")
        )
    )
    
    await update.inline_query.answer(results, cache_time=0, is_personal=True)
