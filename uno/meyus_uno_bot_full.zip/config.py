import os
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("TELEGRAM_TOKEN")
# GitHub'a yüklediğiniz kartların ana dizini
# Örn: https://raw.githubusercontent.com/kullanici/repo/main/uno/cards/
CARD_BASE_URL = os.getenv("CARD_BASE_URL", "https://raw.githubusercontent.com/cryptohisoka1-hue/Meyus-Music/main/uno/cards/")

# Veritabanı adı
DB_NAME = "uno.db"
