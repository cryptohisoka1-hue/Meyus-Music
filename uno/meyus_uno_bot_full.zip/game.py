import random

def create_deck():
    colors = ["red", "blue", "green", "yellow"]
    deck = []
    card_id = 0
    
    for color in colors:
        # 0 (1 adet)
        deck.append({"id": f"card_{card_id:03d}", "color": color, "value": "0", "file": f"card_{card_id:03d}_{color}_0.png"})
        card_id += 1
        # 1-9 (2 adet)
        for i in range(1, 10):
            for _ in range(2):
                deck.append({"id": f"card_{card_id:03d}", "color": color, "value": str(i), "file": f"card_{card_id:03d}_{color}_{i}.png"})
                card_id += 1
        # Aksiyonlar (2 adet)
        for action in ["skip", "reverse", "draw2"]:
            for _ in range(2):
                deck.append({"id": f"card_{card_id:03d}", "color": color, "value": action, "file": f"card_{card_id:03d}_{color}_{action}.png"})
                card_id += 1
                
    # Jokerler (4 adet)
    for _ in range(4):
        deck.append({"id": f"card_{card_id:03d}", "color": "wild", "value": "wild", "file": f"card_{card_id:03d}_wild.png"})
        card_id += 1
        deck.append({"id": f"card_{card_id:03d}", "color": "wild", "value": "draw4", "file": f"card_{card_id:03d}_wild_draw4.png"})
        card_id += 1
        
    random.shuffle(deck)
    return deck

def can_play(card, top_card, current_color):
    if card["color"] == "wild":
        return True
    if card["color"] == current_color:
        return True
    if card["value"] == top_card["value"]:
        return True
    return False
