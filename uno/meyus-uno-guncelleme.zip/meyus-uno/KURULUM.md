# Meyus UNO — Güncelleme Notları

## Ne değişti?
- `/baslat` artık kartları **özelden (DM) göndermiyor**. Bu yüzden "önce bana özel mesaj at" uyarısı tamamen kalktı.
- Kartlar artık **görsel (resim) olarak**, `@botadi` inline sorgusu ile **sadece isteyen oyuncuya özel** gösteriliyor. Gruptaki diğer oyuncular hiçbir şey görmez.
- Kart görselleri özgün olarak üretildi (Mattel'in resmi UNO tasarımı kopyalanmadı — telif nedeniyle).

## Yapman gerekenler

### 1) ÖNCELİKLE eski token'ı iptal et
`config.py` içinde token açık şekilde yazılıydı ve public GitHub reposunda görünüyordu. Bu ciddi bir güvenlik açığı:
- Telegram'da **@BotFather** → `/revoke` → botunu seç → yeni token al.
- Yeni token'ı asla kod içine yazma, ortam değişkeni (environment variable) olarak ver:
  ```bash
  export BOT_TOKEN="yeni_token_buraya"
  ```

### 2) Botta inline modu aç
@BotFather → botunu seç → **Bot Settings → Inline Mode → Turn on**
(Bu olmadan `@botadi` ile kart gösterme çalışmaz.)

### 3) Kart görsellerini yayınla
`assets/cards/` klasöründeki 54 PNG dosyasını GitHub reponda `main` dalına push et.
Sonra `config.py`'deki `CARD_IMAGE_BASE_URL` değerini kendi reponun raw linkiyle eşleştiğinden emin ol:
```
https://raw.githubusercontent.com/<kullanici>/<repo>/main/assets/cards
```
(Repo adın ve kullanıcı adın zaten şablonda dolu geldi, sadece doğrula.)

### 4) Kurulum
```bash
pip install -r requirements.txt
export BOT_TOKEN="yeni_token"
python3 main.py
```

## Kullanım akışı
1. `/oyun` → lobi açılır
2. Oyuncular "➕ Katıl" butonuna basar
3. "▶️ Başlat" veya `/baslat` → oyun başlar
4. Her oyuncu gruba `@botadi` yazıp **boşluk bırakır** → kendi kartlarının görsellerini **sadece kendisi görür** (önizleme, gönderilmez)
5. Kart oynadıkça/çekince eli değişir; her güncellemede tekrar `@botadi` yazılması yeterli.

## Notlar / sınırlar
- Şu anki `game.py` kart oynama (play/turn) mantığını henüz içermiyor — sadece dağıtım ve gösterim var. Sıra sistemi, üst kart takibi, kural kontrolü gibi kısımlar ayrı bir geliştirme gerektirir; istersen onu da ekleyebilirim.
- Inline sonuçlarda kullanıcı bir kartı **seçip gönderirse** o görsel gruba düşer — açıklamada "GÖNDERME" uyarısı var ama teknik olarak yine de mümkün. Tamamen garantili gizlilik istersen alternatif olarak callback+`show_alert` (metin bazlı, resimsiz) yöntemini konuşabiliriz.
